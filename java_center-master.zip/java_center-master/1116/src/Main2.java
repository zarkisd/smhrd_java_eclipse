
public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		addressList add = new addressList();
		add.name = "����ȣ";
		add.age = 28;
		add.contactInformation = "010-3631-8127";

		add.showAddr();

		addressList add2 = new addressList();
		
		
		
		add2.name = "��������";
		add2.age = 35;
		add2.contactInformation = "111-1111-1111";
		
		add2.showAddr();
	}

}
