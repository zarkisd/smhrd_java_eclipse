package chapter5;

public interface ex09stack {

	int length();

	int capacity();

	String pop();

	boolean push(String val);

}
