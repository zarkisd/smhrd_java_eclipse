package myPageController;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.drug.model.PillDAO;
import kr.drug.model.PillVO;

@WebServlet("/mypageController_new.do")
public class mypageController_new extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/plain;charset=euc-kr");
		
		PillDAO dao = new PillDAO();
		
		String userid = "aaa";
		String addpills = null;
		int pillnum=1;
		String dayname = "";
		int count=0;

		String pillname=request.getParameter("pillname");
	    
	    
		
		//pillnum=Integer.parseInt(request.getParameter("hidden-pillnum"));
		System.out.println("pillnum>>" + pillnum);
	
		
		ArrayList<PillVO> list= dao.getpillList2(pillnum);
		
	
		
		String startdate = request.getParameter("startday");
		String starttime=request.getParameter("starttime");
		String hiddenchange=request.getParameter("change");
		System.out.println("hidden-change>>"+hiddenchange);
		System.out.println("starttime>>"+starttime);
		System.out.println("startdate>>"+startdate);
	
		String dailyname=request.getParameter("hidden");
		System.out.println("������ ��������?  " + dailyname);
		String addpills_ = request.getParameter("addpills");
		System.out.println("addpills>>"+addpills_);
		if (addpills_ != null) {
			PillVO vo2 = new PillVO();
			
		
			
			vo2.setPillcompany(list.get(0).getPillcompany());
			vo2.setPilltotal(list.get(0).getPilltotal());
			vo2.setPillrecommend(list.get(0).getPillrecommend());
			vo2.setPillexpire(list.get(0).getPillexpire());
			vo2.setDayname(dailyname);
			vo2.setStarttime(starttime);
			vo2.setStartdate(startdate);
			vo2.setId(userid);
			vo2.setPillname(list.get(0).getPillname());
			
			int result=dao.InsertStart(vo2);
			
			if(result>0) {System.out.println("starttable�� ����");}
			else {System.out.println("starttable�� ����");}
			response.sendRedirect("mypage/ajaxMypage_new.jsp");

		}

		

		
		
		
		
//		request.setAttribute("userid", userid); // �����ڿ�. �ʿ��Ѱ� ����� ��� �������� ������
//		RequestDispatcher rd = request.getRequestDispatcher("mypage/ajaxMypage_new.jsp");
//		rd.forward(request, response);

		
	}

}
