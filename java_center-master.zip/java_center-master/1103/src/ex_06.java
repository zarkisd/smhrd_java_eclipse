
public class ex_06 {

	public static void main(String[] args) {
//		 ������
		/*
		 * int i = 3; System.out.println(++i); System.out.println(i++);
		 * System.out.println(i);
		 */
		/*
		 * int i=5; System.out.println(--i); int j=5; System.out.println(j--);
		 * System.out.println(j);
		 */
		int opr = 0;
		opr += 3;
		System.out.println(opr++);
		System.out.println(opr);
		System.out.println(++opr);
		System.out.println(opr);
		System.out.println(opr--);
		System.out.println(opr);
		System.out.println(--opr);
		System.out.println(opr);

	}

}
