package kr.drug.model;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class DailyCheckDAO {

	private java.sql.Connection conn = null;
	private PreparedStatement psmt = null;
	private ResultSet rs = null;

	
	private void getConnect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@172.30.1.3:1521:XE";
			String user = "hr";
			String password = "hr";
			conn=DriverManager.getConnection(url,user,password);
			
		} catch (ClassNotFoundException e) {
			System.out.println("���� ����");
		} catch (SQLException e) {
			System.out.println("sql ���� 1");
		}
	}
	private void getClose() {
		try {
			if (rs != null)
				rs.close();
			if (psmt != null)
				psmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public int InsertStart(DailyCheckVO vo) {
		
		   
		
		getConnect();
			String sql = "INSERT INTO dailycheck VALUES (uqdaynum_seq.nextval,?,?,?,?,?)";
			try {
				
				psmt = conn.prepareStatement(sql);
				psmt.setString(1,vo.getPillday());
				psmt.setString(2,vo.getPilltime());
				psmt.setString(3,vo.getPillcheck());
				psmt.setInt(4,vo.getMembernum());
				psmt.setInt(5,vo.getUqnum());
				
				
				return psmt.executeUpdate();
			
			} catch (Exception e) {
				e.printStackTrace();
			}finally {

				getClose();
			}
			return -1; 
		}
	
	

}
