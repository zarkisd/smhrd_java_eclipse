package chapter5;

public class ex13Rect implements ex13Shape {

	private double x;// ����
	private double y;// ����

	public ex13Rect(double x, double y) {

		this.x = x;
		this.y = y;
	}

	@Override
	public void draw() {
		System.out.printf("%.1fX%.1fũ���� �簢���Դϴ�.\n", x, y);
	}

	@Override
	public double getArea() {
		return x * y;
	}

}
