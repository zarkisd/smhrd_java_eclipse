package kr.drug.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.drug.model.exDAO;
import kr.drug.model.exVO;

/**
 * Servlet implementation class WifiTest
 */
@WebServlet("/WifiTest.do")
public class WifiTest extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String a = request.getParameter("pillcheck");
		// a���
		System.out.println(a);
		String day = a.substring(0, 10);
		// ��¥ ���
		System.out.println("��¥ : " + day);
		
		String jodo = a.substring(10, 11);
		//���� ���
		System.out.println("���� :  " + jodo);

		String pillname = a.substring(11);
		//�̸� ���
		System.out.println("�̸� : " + pillname);

		// ��ȣ�ȿ� �ΰ� ��¥, �̸�
		// vo dao
//		exDAO dao = new exDAO();
//		exVO vo = new exVO(day, pillname);
		//db�Է� �޼ҵ�
//		dao.InsertStart(vo);
		//�Ƶ��̳뿡�� ���� �� ��
		int d = 1800;
		int b = 4;
		response.getWriter().print("/{\"pilltime\":" + d + "," + "\"pillday\":" + b + "}/");

		String nextPage = "main.jsp";
	}

//	@Override
//	public String requestHandler(HttpServletRequest request, HttpServletResponse response)
//			throws ServletException, IOException {
//		String pillcheck = request.getParameter("pillcheck");
//		System.out.println(pillcheck);
//		int pilltime = 1800;
//		int pillday = 4;
//		response.getWriter().print("/{\"pilltime\":" + pilltime + "," + "\"pillday\":" + pillday + "}/");
//		return "";
//	}

}
