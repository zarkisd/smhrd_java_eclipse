package chapter5;

public class ex02Won2Dollar extends ex02Converter {
	public ex02Won2Dollar(double ratio) {
		super(ratio);
	}

	@Override
	protected double convert(double src) {

		return (double) src / ratio;
	}

	@Override
	protected String getSrcString() {

		return "��";
	}

	@Override
	protected String getDestString() {

		return "�޷�";
	}

	public static void main(String[] args) {
		ex02Won2Dollar toDollar = new ex02Won2Dollar(1200);
		toDollar.run();

	}
}
