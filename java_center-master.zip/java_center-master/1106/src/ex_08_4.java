
public class ex_08_4 {

	public static void main(String[] args) {
	
		char c='a';
		for(c='a'; c<='z'; c++) {
			System.out.print(c+" ");
		}

	}

}
