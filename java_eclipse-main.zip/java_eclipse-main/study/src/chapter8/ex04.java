package chapter8;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ex04 {
	public static void main(String[] args) {
		try {

			File f = new File("C:\\Users\\smhrd\\Desktop\\chapter8\\ex03.txt");
			FileReader fout = new FileReader(f);
			Scanner scan = new Scanner(fout);
			System.out.println(f.getPath() + " ������ �о� ����մϴ�.");
			int lineNumber = 1;
			while (scan.hasNext()) {
				String line = scan.nextLine();
				System.out.printf("%5d", lineNumber++);
				System.out.println(" : " + line);
			}
			scan.close();
		} catch (IOException e) {
			System.out.println("����� ����");
		} finally {
		}
	}
}
