package kr.mem.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.mem.model.MemberDAO;

public class MemberLoginController implements Controller {

	@Override
	public String requestHandler(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		MemberDAO dao = new MemberDAO();
		boolean succ = dao.isLogin(id, pw);
		String nextPage = "";
		if (succ) {
			HttpSession session=request.getSession();
			session.setAttribute("id", id);
			nextPage = "/MVC2/MemberList.do";
			return nextPage;
		} else {
			nextPage = "/MVC2/MemberLoginForm.do";

			return nextPage;
		}
	}

}
