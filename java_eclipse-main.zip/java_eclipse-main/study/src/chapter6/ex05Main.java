package chapter6;

import java.util.Calendar;

public class ex05Main {
	public static void main(String[] args) {
		Calendar c = Calendar.getInstance();
		int hour = c.get(Calendar.HOUR_OF_DAY);
		int min = c.get(Calendar.MINUTE);
		int ampm = c.get(Calendar.AM_PM);
		System.out.printf("���� �ð��� %d�� %d���Դϴ�.\n", hour, min);
		if (hour > 4 && hour < 12) {
			System.out.println("Good Morning");
		} else if (hour < 18) {
			System.out.println("Good Afternoon");
		} else if (hour < 22) {
			System.out.println("Good Evening");
		} else {
			System.out.println("Good Night");
		}

	}
}
