package chapter6;

public class ex02Main {
	public static void main(String[] args) {
		ex02Circle a=new ex02Circle(2, 3, 5);
		ex02Circle b=new ex02Circle(2, 3, 30);
		System.out.println("�� a : "+ a);
		System.out.println("�� b : "+ b);
		if (a.equals(b)) {
			System.out.println("���� ��");
		} else {
			System.out.println("�ٸ� ��");
		}

	}

}
