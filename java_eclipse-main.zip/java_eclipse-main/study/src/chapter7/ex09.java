package chapter7;

public class ex09 {
	public static void main(String[] args) {
		ex09IStack<Integer> stack = new ex09MyStack<Integer>();
		for (int i = 0; i < 10; i++) {
			stack.push(i);
		}
		while (true) {
			Integer n = stack.pop();
			if (n == null) {
				break;
			}
			System.out.print(n + " ");
		}
	}
}
