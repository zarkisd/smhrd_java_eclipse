package chapter7;

public class openword {
	private String eng;
//���ܾ�
	private String kor;

//�ѱ�
	public openword(String eng, String kor) {
		this.eng=eng;
		this.kor=kor;
	}

	public String getEng() {
		return eng;
	}

	public String getKor() {
		return kor;
	}
	
}
