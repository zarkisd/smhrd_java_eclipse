
public class ex_02 {

	public static void main(String[] args) {

		int[] arr= new int[10];
		for (int j=0;j<10;j++) {
			arr[j]=j+1;
		}
		
		for (int i=0 ; i<arr.length;i++) {
			System.out.println(arr[i]);
		}
		
		

	}

}
