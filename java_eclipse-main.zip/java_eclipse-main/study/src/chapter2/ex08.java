package chapter2;

import java.util.Scanner;

public class ex08 {
	final static int rectx1 = 100;
	final static int rectx2 = 200;
	final static int recty1 = 100;
	final static int recty2 = 200;

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("�� ���� ��ǥ�� �Է��ϼ��� >> ");
		System.out.println(doubleInRect(scan.nextInt(), scan.nextInt(), scan.nextInt(), scan.nextInt()));
	}

	public static boolean inRect(int x, int y) {
		if ((x >= rectx1 && x <= rectx2) && (y >= recty1 && y <= recty2))
			return true;
		else
			return false;
	}

	public static String doubleInRect(int x1, int y1, int x2, int y2) {
		String result = "";
		if (inRect(x1, y1) && inRect(x2, y2)) {
			result = "�ȿ� �ֽ��ϴ�.";
			return result;
		} else {
			result = "�浹�ϰų� �ٱ��� �ֽ��ϴ�.";
			return result;
		}
	}
}
