package chapter7;

public abstract class ex10Shape {
	private ex10Shape next;

	public ex10Shape() {
		next = null;
	}

	public abstract void draw();

	public void setNext(ex10Shape obj) {
		next = obj;
	}
	public ex10Shape getNext() {
		return next;
	}

}
