package kr.mem.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.mem.model.MemberDAO;
import kr.mem.model.MemberVO;

public class MemberUpdateController implements Controller {

	@Override
	public String requestHandler(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		MemberDAO dao = new MemberDAO();
		String num1 = request.getParameter("num");
		int num = Integer.parseInt(num1);
		String tel = request.getParameter("tel");
		String email = request.getParameter("email");
		String addr = request.getParameter("addr");
		MemberVO vo = new MemberVO(num, tel, email, addr);
		if (dao.memberUpdate(vo) > 0) {
			return "/MemberList.do";
		} else {
			throw new ServletException("���� ����");
		}

	}
}
