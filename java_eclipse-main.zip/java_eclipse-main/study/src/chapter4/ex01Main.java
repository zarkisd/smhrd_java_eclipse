package chapter4;

public class ex01Main {
	public static void main(String[] args) {
		ex01TV myTV = new ex01TV("LG", 2017, 32);
		myTV.show();
	}
}
