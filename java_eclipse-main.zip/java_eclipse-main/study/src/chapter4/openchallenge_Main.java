package chapter4;

public class openchallenge_Main {
	public static void main(String[] args) {
		openWordGameApp gameStart = new openWordGameApp();
		gameStart.run();
	}
}
