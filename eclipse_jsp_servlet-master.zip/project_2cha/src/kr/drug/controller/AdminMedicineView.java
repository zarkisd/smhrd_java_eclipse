package kr.drug.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.drug.frontcontroller.Controller;
import kr.drug.model.PillInfoDAO;
import kr.drug.model.PillInfoVO;

public class AdminMedicineView implements Controller {

	@Override
	public String requestHandler(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("���� ���°� Ȯ��");
		System.out.println(request.getParameter("pillnum"));
		// pillnum ���°� Ȯ��
		int pillnum = Integer.parseInt(request.getParameter("pillnum"));
		System.out.println(pillnum + "�̰� ��Ʈ�� ����ȯ");
		PillInfoDAO dao = new PillInfoDAO();
		PillInfoVO vo = dao.pillContent(pillnum);
		
		HttpSession session = request.getSession();
		session.setAttribute("vo", vo);// ��ü���ε�

		return "admin/adminMedicineView.jsp";

	}

}
