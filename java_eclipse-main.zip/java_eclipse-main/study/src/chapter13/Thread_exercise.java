package chapter13;

public class Thread_exercise {
	public static void main(String[] args) {

		TimerThread th = new TimerThread();
		th.start();
	}
}

class TimerThread extends Thread {
	
	int n = 10;
	@Override
	public void run() {
		while (true) {
			
			System.out.println(n--);
			try {
				
				sleep(1000);
			} catch (InterruptedException e) {
				System.out.println("����");
				return;
			}

		}

	}

}