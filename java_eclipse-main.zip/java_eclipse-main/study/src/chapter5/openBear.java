package chapter5;

import java.util.Scanner;

public class openBear extends openGameObject {

	Scanner scan = new Scanner(System.in);

	public openBear(int x, int y, int distance) {
		super(x, y, distance);
	}

	@Override
	protected void move() {
		//���� ��ġ ����
		mx = x;
		my = y;
		String tmp = scan.next();
		char c = tmp.charAt(0);
		switch (c) {
		//�� ������ ��ġ�ϸ� �״�� �ְ���
		case 'a':
			if (x == 0) {
				x = 0;
			} else {
				x -= distance;
			}
			break;

		case 's':
			if (y == 20) {
				y = 20;
			} else {
				y += distance;
			}
			break;
		case 'w':
			if (y == 0) {
				y = 0;
			} else {
				y -= distance;
			}
			break;
		case 'd':
			if (x == 10) {
				x = 10;
			} else {
				x += distance;
			}
			break;

		}

	}

	@Override
	protected char getShape() {
		return 'B';
	}

}
