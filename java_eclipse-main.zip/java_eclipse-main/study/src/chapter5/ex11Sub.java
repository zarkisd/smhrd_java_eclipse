package chapter5;

public class ex11Sub extends ex11Calc {

	@Override
	int calculate() {

		return a - b;
	}

}
