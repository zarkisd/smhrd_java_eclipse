package com.Model;

public class SmartDTO {
//2���ʵ� id, pw
	private String id;
	private String pw;

	public SmartDTO(String id, String pw) {

		this.id = id;
		this.pw = pw;
	}

	public String getId() {
		return id;
	}

	public String getPw() {
		return pw;
	}

}
