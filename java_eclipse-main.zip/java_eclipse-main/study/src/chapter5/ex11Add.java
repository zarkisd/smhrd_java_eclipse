package chapter5;

public class ex11Add extends ex11Calc {

	@Override
	int calculate() {

		return a + b;
	}

}
