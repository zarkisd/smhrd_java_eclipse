package chapter8;

import java.io.FileReader;
import java.io.IOException;

public class ex03 {
	public static void main(String[] args) {

		try {
			FileReader fin = new FileReader("C:\\Users\\smhrd\\Desktop\\chapter8\\ex03.txt");
			int c;
			while ((c = fin.read()) != -1) {
				char a=(char) c;
				if(Character.isLowerCase(a)) {
					a=Character.toUpperCase(a);
				}
				System.out.print((char) a);
			}

			fin.close();

		} catch (IOException e) {
			System.out.println("����� ����");
		}

	}
}
