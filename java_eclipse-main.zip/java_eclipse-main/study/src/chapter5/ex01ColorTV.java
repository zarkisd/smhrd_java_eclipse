package chapter5;

public class ex01ColorTV extends ex01TV {
	protected int color;

	public ex01ColorTV(int size, int color) {
		super(size);
		this.color = color;
	}

	public void printProperty() {
		System.out.printf("%d��ġ %d�÷�", getSize(), color);
	}

	public static void main(String[] args) {
		ex01ColorTV myTV = new ex01ColorTV(32, 1024);
		myTV.printProperty();
	}

}
