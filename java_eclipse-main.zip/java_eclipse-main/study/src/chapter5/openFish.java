package chapter5;

public class openFish extends openGameObject {

	public openFish(int x, int y, int distance) {
		super(x, y, distance);
	}

	@Override
	protected void move() {
		//���� ��ġ ����
		mx = x;
		my = y;
		
		int n = (int) (Math.random() * 4);
		switch (n) {
		case 0:
			if (x == 0) {
				x = 0;
			} else {
				x -= distance;
			}
			break;

		case 1:
			if (y == 20) {
				y = 20;
			} else {
				y += distance;
			}
			break;
		case 2:
			if (y == 0) {
				y = 0;
			} else {
				y -= distance;
			}
			break;
		case 3:
			if (x == 10) {
				x = 10;
			} else {
				x += distance;
			}
			break;

		}

	}

	@Override
	protected char getShape() {
		return '@';
	}

}
