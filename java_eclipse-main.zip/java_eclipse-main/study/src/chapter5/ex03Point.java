package chapter5;

public class ex03Point {
	private int x, y;

	public ex03Point() {

	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public ex03Point(int x, int y) {
		this.x = x;
		this.y = y;
	}

	protected void move(int x, int y) {
		this.x = x;
		this.y = y;
	}

	@Override
	public String toString() {
		return "(" + x + "," + y  + ")�� ��";
	}

	
}
