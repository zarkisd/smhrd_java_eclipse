package kr.drug.model;

public class DailyCheckVO {
	private int uqday;
	private String pillday;
	private String pilltime;
	private String pillcheck;
	private int membernum;
	private int uqnum;

	public DailyCheckVO() {
	}

	public DailyCheckVO(int uqday, String pillday, String pilltime, String pillcheck, int membernum, int uqnum) {
		super();
		this.uqday = uqday;
		this.pillday = pillday;
		this.pilltime = pilltime;
		this.pillcheck = pillcheck;
		this.membernum = membernum;
		this.uqnum = uqnum;
	}

	public int getUqday() {
		return uqday;
	}

	public void setUqday(int uqday) {
		this.uqday = uqday;
	}

	public String getPillday() {
		return pillday;
	}

	public void setPillday(String pillday) {
		this.pillday = pillday;
	}

	public String getPilltime() {
		return pilltime;
	}

	public void setPilltime(String pilltime) {
		this.pilltime = pilltime;
	}

	public String getPillcheck() {
		return pillcheck;
	}

	public void setPillcheck(String pillcheck) {
		this.pillcheck = pillcheck;
	}

	public int getMembernum() {
		return membernum;
	}

	public void setMembernum(int membernum) {
		this.membernum = membernum;
	}

	public int getUqnum() {
		return uqnum;
	}

	public void setUqnum(int uqnum) {
		this.uqnum = uqnum;
	}

	@Override
	public String toString() {
		return "DailyCheckVO [uqday=" + uqday + ", pillday=" + pillday + ", pilltime=" + pilltime + ", pillcheck="
				+ pillcheck + ", membernum=" + membernum + ", uqnum=" + uqnum + "]";
	}

}
