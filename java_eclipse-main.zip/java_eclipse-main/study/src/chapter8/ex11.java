package chapter8;

public class ex11 {
	public static void main(String[] args) {
		ex11WordSearch ws = new ex11WordSearch();
		ws.run();
	}
}
