package chapter4;

public class ex07Day {
// �� �� ����
	private String work;

	public String getWork() {
		return work;
	}

	public void setWork(String work) {
		this.work = work;
	}

	public void show() {
		if (work == null) {
			System.out.println("�����ϴ�.");
		} else {
			System.out.println(work + "�Դϴ�.");
		}
	}

}
