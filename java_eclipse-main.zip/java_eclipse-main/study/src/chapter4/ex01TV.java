package chapter4;

public class ex01TV {
	private String name;
	private int year;
	private int inch;

	public ex01TV(String name, int year, int inch) {
		this.name = name;
		this.year = year;
		this.inch = inch;
	}

	public void show() {
		System.out.printf("%s���� ���� %d���� %d��ġ TV", name, year, inch);
	}

}
