package kr.drug.model;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class PillInfoDAO {
	private java.sql.Connection conn = null;
	private PreparedStatement psmt = null;
	private ResultSet rs = null;

	private void getConnect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@172.30.1.3:1521:XE";
			String user = "hr";
			String password = "hr";
			conn = DriverManager.getConnection(url, user, password);

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	private void getClose() {
		try {
			if (rs != null)
				rs.close();
			if (psmt != null)
				psmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int InsertStart(PillInfoVO vo) {

		getConnect();
		String sql = "INSERT INTO pillinfo VALUES (pillinfo_seq.nextval, ?, ?, ?,?,?,?)";
		try {

			psmt = conn.prepareStatement(sql);
			psmt.setString(1, vo.getPillname());
			psmt.setInt(2, vo.getPilltotal());
			psmt.setInt(3, vo.getPillrecommend());
			psmt.setString(4, vo.getPillcompany());
			psmt.setString(5, vo.getPillexpire());
			psmt.setString(6, vo.getPillcategory());

			return psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}
		return -1;
	}

	public ArrayList<PillInfoVO> getpillList() {
		ArrayList<PillInfoVO> list = new ArrayList<PillInfoVO>();
		getConnect();
		String sql = "select pillnum,pillname,pillcompany, pillcategory from pillInfo order by pillnum";

		try {
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			while (rs.next()) {
				int pillnum = rs.getInt("pillnum");
				String pillname = rs.getString("pillname");
				String pillcompany = rs.getString("pillcompany");
				String pillcategory = rs.getString("pillcategory");

				PillInfoVO vo = new PillInfoVO(pillnum, pillname, pillcompany, pillcategory);
				list.add(vo);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}

		return list;

	}

	public PillInfoVO pillContent(int pillnum) {
		PillInfoVO vo = new PillInfoVO();
		getConnect();
		String sql = "select pillname, pilltotal, pillrecommend, pillcompany, pillexpire from pillinfo where pillnum=?";

		try {
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, pillnum);

			rs = psmt.executeQuery();
			while (rs.next()) {
				String pillname = rs.getString(1);
				int pilltotal = rs.getInt(2);
				int pillrecommend = rs.getInt(3);
				String pillcompany = rs.getString(4);
				String pillexpire = rs.getString(5);

				vo = new PillInfoVO(pillnum, pillname, pilltotal, pillrecommend, pillcompany, pillexpire);

			}
			getClose();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vo;

	}

	public int update(PillInfoVO vo) {

		getConnect();
		String sql = "update pillinfo set pillname=? , pilltotal=? , pillrecommend=? , pillcompany=? , pillexpire=? , pillcategory=? where pillnum=?";
		try {

			psmt = conn.prepareStatement(sql);

			psmt.setString(1, vo.getPillname());
			psmt.setInt(2, vo.getPilltotal());
			psmt.setInt(3, vo.getPillrecommend());
			psmt.setString(4, vo.getPillcompany());
			psmt.setString(5, vo.getPillexpire());
			psmt.setString(6, vo.getPillcategory());
			psmt.setInt(7, vo.getPillnum());

			return psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}
		return -1;
	}

}
