package kr.drug.model;

public class exVO {
	String ab;
	String abc;
	String abcd;

	public String getAb() {
		return ab;
	}

	public void setAb(String ab) {
		this.ab = ab;
	}

	public String getAbc() {
		return abc;
	}

	public void setAbc(String abc) {
		this.abc = abc;
	}

	public String getAbcd() {
		return abcd;
	}

	public void setAbcd(String abcd) {
		this.abcd = abcd;
	}

	public exVO(String ab, String abc, String abcd) {
		this.ab = ab;
		this.abc = abc;
		this.abcd = abcd;
	}

}
