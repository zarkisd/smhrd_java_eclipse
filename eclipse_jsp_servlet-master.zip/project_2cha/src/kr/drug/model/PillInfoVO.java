package kr.drug.model;

public class PillInfoVO {

	private int pillnum;
	private String pillname;
	private int pilltotal;
	private int pillrecommend;
	private String pillcompany;
	private String pillexpire;
	private String pillcategory;

	public PillInfoVO(int pillnum, String pillname, int pilltotal, int pillrecommend, String pillcompany,
			String pillexpire) {
		this.pillnum = pillnum;
		this.pillname = pillname;
		this.pilltotal = pilltotal;
		this.pillrecommend = pillrecommend;
		this.pillcompany = pillcompany;
		this.pillexpire = pillexpire;
	}

	public PillInfoVO(int pillnum, String pillname, String pillcompany, String pillcategory) {
		this.pillnum = pillnum;
		this.pillname = pillname;
		this.pillcompany = pillcompany;
		this.pillcategory = pillcategory;
	}

	public PillInfoVO(String pillname, int pilltotal, int pillrecommend, String pillcompany, String pillexpire,
			String pillcategory) {
		this.pillname = pillname;
		this.pilltotal = pilltotal;
		this.pillrecommend = pillrecommend;
		this.pillcompany = pillcompany;
		this.pillexpire = pillexpire;
		this.pillcategory = pillcategory;
	}

	public PillInfoVO() {
	}

	public PillInfoVO(int pillnum, String pillname, int pilltotal, int pillrecommend, String pillcompany,
			String pillexpire, String pillcategory) {
		this.pillnum = pillnum;
		this.pillname = pillname;
		this.pilltotal = pilltotal;
		this.pillrecommend = pillrecommend;
		this.pillcompany = pillcompany;
		this.pillexpire = pillexpire;
		this.pillcategory = pillcategory;
	}

	public String getPillcategory() {
		return pillcategory;
	}

	public void setPillcategory(String pillcategory) {
		this.pillcategory = pillcategory;
	}

	public int getPillnum() {
		return pillnum;
	}

	public void setPillnum(int pillnum) {
		this.pillnum = pillnum;
	}

	public String getPillname() {
		return pillname;
	}

	public void setPillname(String pillname) {
		this.pillname = pillname;
	}

	public int getPilltotal() {
		return pilltotal;
	}

	public void setPilltotal(int pilltotal) {
		this.pilltotal = pilltotal;
	}

	public int getPillrecommend() {
		return pillrecommend;
	}

	public void setPillrecommend(int pillrecommend) {
		this.pillrecommend = pillrecommend;
	}

	public String getPillcompany() {
		return pillcompany;
	}

	public void setPillcompany(String pillcompany) {
		this.pillcompany = pillcompany;
	}

	public String getPillexpire() {
		return pillexpire;
	}

	public void setPillexpire(String pillexpire) {
		this.pillexpire = pillexpire;
	}

	@Override
	public String toString() {
		return "PillInfoDAO [pillnum=" + pillnum + ", pillname=" + pillname + ", pilltotal=" + pilltotal
				+ ", pillrecommend=" + pillrecommend + ", pillcompany=" + pillcompany + ", pillexpire=" + pillexpire
				+ "]";
	}

}
