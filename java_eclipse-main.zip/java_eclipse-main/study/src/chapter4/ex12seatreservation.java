package chapter4;

import java.util.Scanner;

public class ex12seatreservation {
	String[][] SeatType = new String[3][10];
	Scanner scan = new Scanner(System.in);
	
	public void reserve() {
		System.out.print("�¼����� S(1), A(2), B(3)>>");
		int type = scan.nextInt();
		//s a b  ����
		for (int i = 0; i < SeatType[type - 1].length; i++) {
			System.out.print(SeatType[type - 1][i]);
		}
		System.out.print("\n�̸� >> ");
		String name = scan.next();
		System.out.print("��ȣ >> ");
		int num = scan.nextInt();
		if (num > 10 || num < 0) {
			System.out.println("�߸� �Է��Ͽ����ϴ�.");
		}
		SeatType[type - 1][num - 1] = name + " ";
	}

	public void show() {

		for (int i = 0; i < SeatType.length; i++) {
			for (int j = 0; j < SeatType[i].length; j++) {
				System.out.print(SeatType[i][j]);
			}
			System.out.println();
		}
		System.out.println("��ȸ�� �Ϸ��Ͽ����ϴ�.");
	}

	public void cancel() {
		System.out.print("�¼����� S(1), A(2), B(3)>>");
		int num = scan.nextInt();
		/*
		 * System.out.print("�̸� >>"); String name = scan.next(); for (int i = 0; i <
		 * SeatType[num - 1].length; i++) { if (SeatType[num - 1][i].equals(name)) {
		 * SeatType[num - 1][i] = "--- "; } } �̸��� �̻��ϰ� �ȵǳ� ��
		 */
		System.out.print("��ȣ >>");
		int seatNum = scan.nextInt();
		SeatType[num - 1][seatNum - 1] = "--- ";

	}

	public void finish() {
		System.out.println("�����մϴ�.");
	}

}
