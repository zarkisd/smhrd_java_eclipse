package chapter4;

public class ex05Circle {
	private double x, y;
	private int radius;

	public ex05Circle(double x, double y, int radius) {

		this.x = x;
		this.y = y;
		this.radius = radius;
	}
	// ��������������

	public void show() {
		System.out.printf("(%.1f, %.1f) %d\n", x, y, radius);
	}

	public int getRadius() {
		return radius;
	}
}
