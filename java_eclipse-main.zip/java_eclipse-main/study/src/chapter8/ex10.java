package chapter8;

public class ex10 {
	public static void main(String[] args) {
		ex10PhoneBook pb = new ex10PhoneBook();
		pb.run();
	}
}
