package chapter7;

import java.util.Scanner;
import java.util.Vector;

public class ex04 {
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		Vector<Integer> v = new Vector<Integer>();
		while (true) {
			System.out.print("������ �Է�(0 �Է½� ����)>>");
			int num = scan.nextInt();
			if (num == 0) {
				break;
			}
			v.add(num);
			// �迭 ����, �ֻ���
			Object[] arr = v.toArray();
			int sum = 0;
			for (int i = 0; i < arr.length; i++) {
				System.out.print(arr[i] + " ");
				sum += (int) (arr[i]);
			}
			System.out.println("\n���� ��� : " + (double) (sum / arr.length));
		}
	}

}

