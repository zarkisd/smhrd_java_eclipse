
public class free_���밪 {

	public static void main(String[] args) {

		
		System.out.println(absoulte(4,9));
		

	}
	
	
	public static int absoulte(int m, int n) {
		int result=0;
		if(m>n) {
			result=m-n;
		}
		else {
			result=-(m-n);
		}
		
		return result;
		
		

	}

}
