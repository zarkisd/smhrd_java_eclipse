package Mousepackage;

public class WheelMouse extends Mouse {
	public void scroll() {
		System.out.println("��ũ���ϱ�");
	}
}
