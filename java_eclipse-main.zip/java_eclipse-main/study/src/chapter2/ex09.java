package chapter2;

import java.util.Scanner;

public class ex09 {
	public static void main(String[] args) {
		double x, y, r;
		Scanner scan = new Scanner(System.in);
		System.out.print("���� �߽ɰ� ������ �Է� >>");
		x = scan.nextDouble();
		y = scan.nextDouble();
		r = scan.nextDouble();
		System.out.print("�� �Է� >>");
		System.out.println(InCircle(scan.nextDouble(), scan.nextDouble(), x, y, r));

	}

	public static String InCircle(double x1, double y1, double x, double y, double r) {
		String result = "";
		double value = Math.sqrt((x1 - x) * (x1 - x) + (y1 - y) * (y1 - y));
		if (value > r) {
			result = String.format("�� (%.1f, %.1f)�� �� �ۿ� �ִ�.", x1, y1);
		} else {
			result = String.format("�� (%.1f, %.1f)�� �� �ȿ� �ִ�.", x1, y1);
		}
		return result;
	}
}
