package chapter6;

public class ex02Circle {
	private double x, y,r;

	public ex02Circle(double x, double y, double r) {
		this.x = x;
		this.y = y;
		this.r = r;
	}

	public boolean equals(ex02Circle c) {
		boolean result = true;
		if (x == c.x && y == c.y) {
			return result;
		} else {
			return false;
		}

	}

	@Override
	public String toString() {
		return "Circle (x=" + x + ", y=" + y + ") ������ "+ r;
	}
	
	
}
