package chapter4;

public class ex07Main {
	public static void main(String[] args) {
		ex07MonthSchedule may = new ex07MonthSchedule(31);
		may.run();
	}

}
