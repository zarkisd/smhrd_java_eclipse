package kr.drug.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.drug.frontcontroller.Controller;
import kr.drug.model.PillInfoDAO;
import kr.drug.model.PillInfoVO;

public class AddMedicine implements Controller {

	@Override
	public String requestHandler(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String pillname = request.getParameter("pillname");
		int pilltotal = Integer.parseInt(request.getParameter("pilltotal"));
		int pillrecommend = Integer.parseInt(request.getParameter("pillrecommend"));
		String pillcompany = request.getParameter("pillcompany");
		String pillexpire = request.getParameter("pillexpire");
		String pillcategory = request.getParameter("pillcategory");
		// Ȯ�ο�
		System.out.println(pillname + " \t" + pillrecommend + " \t" + pilltotal + " \t" + pillcompany + " \t"
				+ pillexpire + " \t" + pillcategory);
		//
		PillInfoDAO dao = new PillInfoDAO();
		PillInfoVO vo = new PillInfoVO(pillname, pilltotal, pillrecommend, pillcompany, pillexpire, pillcategory);

		int cnt = dao.InsertStart(vo);
		if (cnt > 0) {
			System.out.println("db �Է� ����");
			return "admin/adminMedicine.jsp";
		} else {
			throw new ServletException("db �Է� ����");
		}
	}

}
