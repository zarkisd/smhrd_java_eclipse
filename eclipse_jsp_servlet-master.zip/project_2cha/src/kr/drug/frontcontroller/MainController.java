package kr.drug.frontcontroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.drug.controller.AddMedicine;
import kr.drug.controller.AdminMedicineView;
import kr.drug.controller.MedicineView;
import kr.drug.controller.UpdateMedicine;
import kr.drug.controller.WifiTest;
import myPageController.ajaxMypage_new;
import myPageController.chogi;
import myPageController.mypageController_new;

@WebServlet("*.do")
public class MainController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		String reqPath = request.getRequestURI();
		String contextPath = request.getContextPath();
		String command = reqPath.substring(contextPath.length());
		System.out.println("��û�� ������ Ȯ�� : " + command);
		Controller controller = null;

		String nextPage = null;
		if (command.equals("/AddMedicine.do")) {
			controller = new AddMedicine();
			nextPage = controller.requestHandler(request, response);
			response.sendRedirect(nextPage);
			// sqlupdate->sendredirect
		} else if (command.equals("/WifiTest.do")) {
			WifiTest wifi = new WifiTest();
			nextPage = ((Controller) wifi).requestHandler(request, response);
			response.sendRedirect(nextPage);
//			RequestDispatcher rd = request.getRequestDispatcher(nextPage);
//			rd.forward(request, response);
		} else if (command.equals("/AdminMedicineView.do")) {
			controller = new AdminMedicineView();
			nextPage = controller.requestHandler(request, response);
			response.sendRedirect(nextPage);
			// ��¿�� ���� css������
//			RequestDispatcher rd = request.getRequestDispatcher(nextPage);
//			rd.forward(request, response);
		}

		else if (command.equals("/mypageController_new.do")) {
			controller = (Controller) new mypageController_new();
			nextPage = controller.requestHandler(request, response);
			RequestDispatcher rd = request.getRequestDispatcher(nextPage);
			rd.forward(request, response);

		} else if (command.equals("/chogi.do")) {
			controller = (Controller) new chogi();
			nextPage = controller.requestHandler(request, response);
			RequestDispatcher rd = request.getRequestDispatcher(nextPage);
			rd.forward(request, response);
			// response.sendRedirect(nextPage);
			// update delete insert
		} else if (command.equals("/ajaxMypage_new.do")) {
			controller = (Controller) new ajaxMypage_new();
			nextPage = controller.requestHandler(request, response);
			RequestDispatcher rd = request.getRequestDispatcher(nextPage);
			rd.forward(request, response);

		}else if (command.equals("/MedicineView.do")) {
			controller = new MedicineView();
			nextPage = controller.requestHandler(request, response);
			RequestDispatcher rd = request.getRequestDispatcher(nextPage);
			rd.forward(request, response);

		}else if (command.equals("/UpdateMedicine.do")) {
			controller = new UpdateMedicine();
			nextPage = controller.requestHandler(request, response);
			response.sendRedirect(nextPage);

		}

	}

}
