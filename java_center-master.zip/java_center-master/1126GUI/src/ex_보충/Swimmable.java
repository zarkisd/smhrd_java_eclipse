package ex_����;

public interface Swimmable {
	public abstract void swimming();
}
