package chapter6;

public class ex01Main {
	public static void main(String[] args) {
		ex01MyPoint p = new ex01MyPoint(3, 50);
		ex01MyPoint q = new ex01MyPoint(4, 50);
		System.out.println(p);
		if (p.equals(q)) {
			System.out.println("���� ��");
		} else {
			System.out.println("�ٸ� ��");
		}

	}
}
