package chapter7;

public class ex10Line extends ex10Shape {
	String name="Line";
	@Override
	public void draw() {
		System.out.println("Line");
	}
}
