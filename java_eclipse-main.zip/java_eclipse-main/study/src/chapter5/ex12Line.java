package chapter5;

public class ex12Line extends ex12Shape {
	String name="Line";
	@Override
	public void draw() {
		System.out.println("Line");
	}
}
