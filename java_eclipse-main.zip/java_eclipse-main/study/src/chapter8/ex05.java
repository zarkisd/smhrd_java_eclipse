package chapter8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.TreeMap;

public class ex05 {
	public static void main(String[] args) {
		TreeMap<String, String> tm = new TreeMap<>();
		File first = new File("C:\\Users\\smhrd\\Desktop\\chapter8\\elvis1.txt");
		File second = new File("C:\\Users\\smhrd\\Desktop\\chapter8\\elvis1_copy.txt");

		System.out.println("���� �����̸� �ƹ����� ��������ʽ��ϴ� >>");
		BufferedReader bf = null;
		try {
			bf = new BufferedReader(new FileReader(second));
			while (true) {
				String str = bf.readLine();
				if (str == null) {
					break;
				}
				tm.put(str, str);
			}
			bf = new BufferedReader(new FileReader(first));
			while (true) {
				String str = bf.readLine();
				if (str == null) {
					break;
				}
				String tmp = tm.get(str);
				if (tmp == null) {
					System.out.println(str);
				}
			}
		} catch (IOException e) {
			System.out.println("����� ����");
		}

	}
}
