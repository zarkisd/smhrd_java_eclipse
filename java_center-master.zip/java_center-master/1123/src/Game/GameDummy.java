package Game;

public class GameDummy implements IGame {

	@Override
	public void makeRandom() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getQuizMsg() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean checkAnswer(int answer) {
		// TODO Auto-generated method stub
		return false;
	}

	

}
