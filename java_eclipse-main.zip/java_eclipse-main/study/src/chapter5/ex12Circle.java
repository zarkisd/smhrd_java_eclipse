package chapter5;

public class ex12Circle extends ex12Shape {
	String name = "Circle";

	@Override
	public void draw() {
		System.out.println("Circle");
	}
}
