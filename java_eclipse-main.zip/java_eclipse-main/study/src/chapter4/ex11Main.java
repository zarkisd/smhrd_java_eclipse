package chapter4;

import java.util.Scanner;

public class ex11Main {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("�� ������ �����ڸ� �Է��ϼ���");
		int a = scan.nextInt();
		int b = scan.nextInt();
		String c = scan.next();
		try {
			switch (c) {
			case "+":
				Add add = new Add();
				add.setValue(a, b);
				System.out.println(add.calculate());
				break;
			case "-":
				Sub sub = new Sub();
				sub.setValue(a, b);
				System.out.println(sub.calculate());
				break;
			case "*":
				Mul mul = new Mul();
				mul.setValue(a, b);
				System.out.println(mul.calculate());
				break;
			case "/":
				Div div = new Div();
				div.setValue(a, b);
				System.out.println(div.calculate());
				break;
			}
		} catch (ArithmeticException e) {
			System.out.println("0���� ������ �����ϴ�.");
		}

	}
}

class Add {
	private int a;
	private int b;

	public void setValue(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public int calculate() {
		return a + b;
	}
}

class Sub {
	private int a;
	private int b;

	public void setValue(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public int calculate() {
		return a - b;
	}
}

class Mul {
	private int a;
	private int b;

	public void setValue(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public int calculate() {
		return a * b;
	}
}

class Div {
	private int a;
	private int b;

	public void setValue(int a, int b) {
		this.a = a;
		this.b = b;
	}

	public int calculate() {
		return a / b;
	}

}
