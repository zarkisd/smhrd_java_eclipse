package chapter4;

public class ex04Rectangle {
	private int x;
	private int y;
	private int width;
	private int height;

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public ex04Rectangle(int x, int y, int width, int height) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	public int square() {
		return width * height;
	}

	public void show() {
		System.out.printf("(%d,%d)���� ũ�Ⱑ %dX%d�� �簢��\n", x, y, width, height);
	}

	public boolean contains(ex04Rectangle r) {
		// if ���� �߿�
		if (this.x < r.x && this.y < r.y) {
			if ((this.x + this.width) > (r.getX() + r.getWidth())
					&& (this.y + this.height) > (r.getY() + r.getHeight())) {
				return true;
			}
		}
		return false;

	}
}
