package chapter4;
//java bean�̶� �Ѵ�
public class ex08Phone {
	private String name, tel;

	public ex08Phone(String name, String tel) {
		this.name = name;
		this.tel = tel;
	}

	public String getName() {
		return name;
	}

	public String getTel() {
		return tel;
	}
}
