
public class ex_01_1 {

	public static void main(String[] args) {
		
		
		int[] arr=new int [44];
		for (int i=0; i<44;i++) {
			arr[i]=96-i;
		}
		for (int j=0; j<arr.length;j++) {
			System.out.println(arr[j]);
		}

	}

}
