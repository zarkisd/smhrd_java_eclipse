package chapter4;

public class ex03Main {
	public static void main(String[] args) {

		ex03Song sing = new ex03Song("Dancing Queen", "ABBA", 1978, "������");
		sing.show();
	}
}
