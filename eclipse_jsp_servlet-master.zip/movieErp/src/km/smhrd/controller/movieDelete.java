package km.smhrd.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.smhrd.model.MovieDAO;

/**
 * Servlet implementation class movieDelete
 */
@WebServlet("/movieDelete.do")
public class movieDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public movieDelete() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.setContentType("text/html;charset=EUC-KR");
		request.setCharacterEncoding("EUC-KR");
		PrintWriter out = response.getWriter();
		MovieDAO dao = new MovieDAO();
		int mnum =Integer.parseInt(request.getParameter("mnum"));
		if (dao.movieDelete(mnum) > 0) {
			response.sendRedirect("/movieErp/movieList.do");
		} else {
			out.println("���� ����!!");
		}
	
	}

}
