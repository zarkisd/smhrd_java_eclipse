package chapter2;

import java.util.Scanner;

public class ex06 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("1~99������ ������ �Է��Ͻÿ� >> ");
		int num = scan.nextInt();
		String[] str = (num + "").split("");
		String zzak = "�ڼ�";
		for (int i = 0; i < str.length; i++) {
			if (str[i].equals("3") || str[i].equals("6") || str[i].equals("9")) {
				zzak += "¦";
			}
		}
		System.out.printf("%s", zzak);
	}
}
