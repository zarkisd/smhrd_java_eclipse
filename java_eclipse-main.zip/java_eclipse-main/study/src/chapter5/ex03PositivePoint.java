package chapter5;

public class ex03PositivePoint extends ex03Point {

	public ex03PositivePoint() {
		super(0, 0);
	}

	public ex03PositivePoint(int x, int y) {

		if (x < 0 || y < 0) {
			super.move(0, 0);
		}

	}

	@Override
	protected void move(int x, int y) {

		if (x > 0 && y > 0) {
			super.move(x, y);
		}
	}

	public static void main(String[] args) {
		ex03PositivePoint p = new ex03PositivePoint();
		p.move(10, 10);
		System.out.println(p.toString() + "�Դϴ�.");

		p.move(-5, 5);
		System.out.println(p.toString() + "�Դϴ�.");

		ex03PositivePoint p2 = new ex03PositivePoint(-10, -10);
		System.out.println(p2.toString() + "�Դϴ�.");

	}
}
