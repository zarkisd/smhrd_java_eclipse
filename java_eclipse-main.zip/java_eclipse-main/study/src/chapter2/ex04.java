package chapter2;

import java.util.Scanner;

public class ex04 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("���� 3���� �Է��ϼ��� >>");
		System.out.println(mid(scan.nextInt(), scan.nextInt(), scan.nextInt()));
	}

//���׿����� ��밡��
	private static int mid(int a, int b, int c) {
		int result = 0;
		if (a > b) {
			if (b > c) {
				result = b;
			} else {
				if (a > c) {
					result = c;
				} else {
					result = a;
				}

			}
		} else {
			if (a > c) {
				result = a;
			} else {
				if (b > c) {
					result = c;
				} else {
					result = b;
				}
			}
		}
		return result;
	}
}
