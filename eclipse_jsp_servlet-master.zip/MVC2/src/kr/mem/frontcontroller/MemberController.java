package kr.mem.frontcontroller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.mem.controller.Controller;
import kr.mem.controller.MemberContentController;
import kr.mem.controller.MemberDeleteController;
import kr.mem.controller.MemberInsertController;
import kr.mem.controller.MemberListController;
import kr.mem.controller.MemberLoginController;
import kr.mem.controller.MemberLoginFormController;
import kr.mem.controller.MemberUpdateController;
import kr.mem.model.MemberDAO;

@WebServlet("*.do")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=EUC-KR");
		request.setCharacterEncoding("EUC-KR");
		// 1. FrontController
		// memberList.do
		// memberInsert.do
		// memberContent.do
		// memberDelete.do
		// memberUpdate.do
		// Ŭ���̾�Ʈ�� ��û�� � ��û���� �˾Ƴ���
		String reqPath = request.getRequestURI();
		// System.out.println(reqPath);
		String contextPath = request.getContextPath();
		// System.out.println(contextPath);
		String command = reqPath.substring(contextPath.length());
		System.out.println("��û�� ������ Ȯ�� : " + command);
		// ��û�� ���� ó��(�б��۾�, if)
		MemberDAO dao = new MemberDAO();
		// dao ���߿� ����
		Controller controller = null;
		String nextPage = null;
		if (command.equals("/MemberList.do")) {
			controller = new MemberListController();
			nextPage = controller.requestHandler(request, response);
			RequestDispatcher rd = request.getRequestDispatcher(nextPage);
			rd.forward(request, response);
		} else if (command.equals("/MemberInsert.do")) {
			controller = new MemberInsertController();
			nextPage = controller.requestHandler(request, response);
			RequestDispatcher rd = request.getRequestDispatcher(nextPage);
			rd.forward(request, response);
		} else if (command.equals("/MemberContent.do")) {
			controller = new MemberContentController();
			nextPage = controller.requestHandler(request, response);
			RequestDispatcher rd = request.getRequestDispatcher(nextPage);
			rd.forward(request, response);
		}

		else if (command.equals("/MemberDelete.do")) {
			controller = new MemberDeleteController();
			nextPage = controller.requestHandler(request, response);
			RequestDispatcher rd = request.getRequestDispatcher(nextPage);
			rd.forward(request, response);

		} else if (command.equals("/MemberUpdate.do")) {
			controller = new MemberUpdateController();
			nextPage = controller.requestHandler(request, response);
			RequestDispatcher rd = request.getRequestDispatcher(nextPage);
			rd.forward(request, response);
			// response.sendRedirect(nextPage);
			// update delete insert
		} else if (command.equals("/MemberLoginForm.do")) {
			controller = new MemberLoginFormController();
			nextPage = controller.requestHandler(request, response);
			response.sendRedirect(nextPage);
		}

		else if (command.equals("/MemberLogin.do")) {
			controller = new MemberLoginController();
			nextPage = controller.requestHandler(request, response);
			response.sendRedirect(nextPage);
		}

	}

}
