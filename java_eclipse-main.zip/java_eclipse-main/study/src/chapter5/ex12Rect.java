package chapter5;

public class ex12Rect extends ex12Shape {
	String name="Rect";
	@Override
	public void draw() {
		System.out.println("Rect");
	}
}
