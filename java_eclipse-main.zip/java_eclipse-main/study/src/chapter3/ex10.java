package chapter3;

public class ex10 {
	public static void main(String[] args) {

		int[][] numArr = new int[4][4];

		int i, j;

		for (i = 0; i < numArr.length; i++) {
			for (j = 0; j < numArr[i].length; j++) {
				numArr[i][j] = (int) (Math.random() * 10 + 1);
			}
		}
		int k = 1;

		while (true) {
			//i�� j ���� 1~4 
			i = (int) (Math.random() * 3 + 1);
			j = (int) (Math.random() * 3 + 1);
			if (numArr[i][j] == 0) {
				continue;
			}
			numArr[i][j] = 0;
			k++;
			if (k == 7) {
				break;
			}
		}

		for (i = 0; i < numArr.length; i++) {
			for (j = 0; j < numArr[i].length; j++) {
				System.out.printf("\t %d ", numArr[i][j]);
			}
			System.out.printf("\n");
		}

	}

}
