package chapter2;

import java.util.Scanner;

public class ex11 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("���� �Է��ϼ���(1~12) >> ");
//		System.out.println(ifAns(scan.nextInt()));
		System.out.println(switchAns(scan.nextInt()));

	}

	public static String ifAns(int month) {
		String result = "";
		if (month / 3 == 1) {
			result = "��";
		} else if (month / 3 == 2) {
			result = "����";
		} else if (month / 3 == 3) {
			result = "����";
		} else {
			result = "�ܿ�";
		}
		return result;
	}

	public static String switchAns(int month) {
		String result = "";
		switch (month / 3) {
		case 1:
			result = "��";
			break;
		case 2:
			result = "����";
			break;
		case 3:
			result = "����";
			break;
		default:
			result = "�ܿ�";
		}
		return result;

	}
}
