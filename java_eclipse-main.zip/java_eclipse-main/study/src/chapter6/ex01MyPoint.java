package chapter6;

public class ex01MyPoint {
	private int x, y;

	public ex01MyPoint(int x, int y) {
		this.x = x;
		this.y = y;
	}

	public boolean equals(ex01MyPoint q) {
		boolean result = true;
		if (x == q.x && y == q.y) {
			return result;
		} else {
			return false;
		}

	}

	@Override
	public String toString() {
		return "Point (x=" + x + ", y=" + y + ")";
	}
	

}
