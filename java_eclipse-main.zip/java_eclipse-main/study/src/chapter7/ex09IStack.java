package chapter7;

public interface ex09IStack<T> {
	T pop();

	boolean push(T ob);

}
