
public class ex_01 {

	public static void main(String[] args) {
		
		
		
		int[] arr= new int[37];
		
		for (int i=0;i<=36;i++) {
			arr[i]=i+21;
		}
			
		for (int j=0;j<arr.length;j++) {
			
			System.out.println(arr[j]);
		}
		
		
		
		

	}

}
