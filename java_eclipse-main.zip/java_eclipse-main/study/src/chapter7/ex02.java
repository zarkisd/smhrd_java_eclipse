package chapter7;

import java.util.ArrayList;
import java.util.Scanner;

public class ex02 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		ArrayList<String> list = new ArrayList<String>();
		System.out.print("6���� ������ �� ĭ���� �и� �Է�(A/B/C/D/F)>>");
		int k = 0;
		double sum = 0;
		// Ƚ��
		while (true) {
			String grade = scan.next();
			list.add(grade);
			k++;
			switch (grade) {
			case "A":
				sum += 4.0;
				break;
			case "B":
				sum += 3.0;
				break;
			case "C":
				sum += 2.0;
				break;
			case "D":
				sum += 1.0;
				break;
			default:
				sum += 0;
				break;
			}
			if (k == 6) {
				break;
			}
		}
		System.out.printf("%.2f",(double) (sum / 6));

	}
}
