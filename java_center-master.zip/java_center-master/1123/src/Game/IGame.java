package Game;

public interface IGame {

	void makeRandom();

	String getQuizMsg();

	boolean checkAnswer(int answer);
	// �� �߻�޼ҵ�
}
