package fes_fianl;

public class fes_31 {

	public static void main(String[] args) {

		fes31Expressions expressions = new fes31Expressions();
		System.out.println(expressions.expressions(36));

	}

}