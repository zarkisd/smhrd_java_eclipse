package chapter5;

public class ex02Km2Mile extends ex02Converter {
	public ex02Km2Mile(double ratio) {
		super(ratio);

	}

	public static void main(String[] args) {
		ex02Km2Mile toMile = new ex02Km2Mile(1.6);
		toMile.run();
	}

	@Override
	protected double convert(double src) {

		return (double) src / ratio;
	}

	@Override
	protected String getSrcString() {
		return "Km";
	}

	@Override
	protected String getDestString() {
		return "mile";
	}
}
