package kr.mem.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.mem.model.MemberDAO;

public class MemberDeleteController implements Controller {

	@Override
	public String requestHandler(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String num = request.getParameter("num");
		MemberDAO dao = new MemberDAO();
		if (dao.memberDelete(num) > 0) {
			return "/MemberList.do";
		} else {
			throw new ServletException("db ���� ����");
		}

	}
}
