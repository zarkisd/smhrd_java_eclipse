package chapter7;

public class ex06Location {
	private String name;
	private int wedo, gyungdo;

	public ex06Location(int wedo, int gyungdo) {

		this.wedo = wedo;
		this.gyungdo = gyungdo;
	}

	public String getName() {
		return name;
	}

	public int getWedo() {
		return wedo;
	}

	public int getGyungdo() {
		return gyungdo;
	}

}
