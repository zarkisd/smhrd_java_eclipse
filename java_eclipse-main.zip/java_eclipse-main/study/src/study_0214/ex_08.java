package study_0214;

public class ex_08 {
	public static void main(String[] args) {
		System.out.println(change124(6));

	}

	public static String change124(int n) {
		String[] num = { "4", "1", "2" };
		String result = "";

		while (n > 0) {
			result = num[n % 3] + result;
			n = (n - 1) / 3;
		}
		return result;

	}
}
