package chapter2;

import java.util.Scanner;

public class ex12 {
	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		System.out.print("���� >> ");
		System.out.print(cal(scan.nextInt(), scan.next(), scan.nextInt()));

	}
//switch�� operator �ϰ� case +-*/ �ϸ� ��� ����
	private static String cal(int num1, String operator, int num2) {
		String result = "";
		int value = 0;
		try {
			if (operator.equals("+")) {
				value = num1 + num2;
			} else if (operator.equals("-")) {
				value = num1 - num2;
			} else if (operator.equals("*")) {
				value = num1 * num2;
			} else if (operator.equals("/")) {
				value = num1 / num2;
			}
			result = String.format("%d %s %d �� ��� ����� %d", num1, operator, num2, value);
		} catch (ArithmeticException e) {
			System.out.println("0���� ���� �� �����ϴ�.");

		}

		return result;

	}
}
