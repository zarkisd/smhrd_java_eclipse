package chapter7;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.StringTokenizer;

public class ex05 {
	public static void main(String[] args) {
		ex05Student[] stu = new ex05Student[4];
		ArrayList<ex05Student> arr = new ArrayList<ex05Student>();

		System.out.println("�л� �̸�, �а�, �й�, ���� ����� �Է��ϼ���.");
		Scanner scan = new Scanner(System.in);
		for (int i = 0; i < stu.length; i++) {
			System.out.print(">> ");
			String text = scan.nextLine();
			//next���� ����  �׳�  next ���� nosuchelementexception ���� ��
			StringTokenizer st = new StringTokenizer(text, ",");
			// ,�� �ڸ� �迭
			// ���� ���� trim
			String name = st.nextToken().trim();
			String department = st.nextToken().trim();
			int number = Integer.parseInt(st.nextToken().trim());
			double grade = Double.parseDouble(st.nextToken().trim());
			stu[i] = new ex05Student(name, department, number, grade);
			arr.add(stu[i]);

		}
		System.out.println("=========================");
		for (int i = 0; i < arr.size(); i++) {
			System.out.println("�̸� : " + stu[i].getName());
			System.out.println("�а� : " + stu[i].getDepartment());
			System.out.println("�й� : " + stu[i].getNumber());
			System.out.println("������� : " + stu[i].getGrade());
			System.out.println("=========================");
		}
		int i = 0;
		while (true) {
			System.out.print("�л� �̸� >> ");
			String name = scan.next();
			if (name.equals("�׸�")) {
				break;
			}
			for (i = 0; i < stu.length; i++) {
				//���
				if (name.equals(stu[i].getName())) {
					System.out.println(stu[i].getName() + ", " + stu[i].getDepartment() + ", " + stu[i].getNumber()
							+ ", " + stu[i].getGrade());
					break;
				}

			}
			if (i == stu.length) {
				System.out.println("�׷� ��� �����");
			}
		}
	}
}
