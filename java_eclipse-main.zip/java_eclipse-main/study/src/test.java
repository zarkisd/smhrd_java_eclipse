import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class test {

	public static void main(String[] args) {
		Set<Integer> set = new HashSet<>();
		while (set.size() < 25) {
			Double d = Math.random() * 25 + 1;
			set.add(d.intValue());
		}
		List<Integer> list = new ArrayList<>(set);
		Collections.sort(list);
		System.out.println(list);
	}

}
