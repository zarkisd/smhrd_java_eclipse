package chapter7;

public class ex10Rect extends ex10Shape {
	String name="Rect";
	@Override
	public void draw() {
		System.out.println("Rect");
	}
}
