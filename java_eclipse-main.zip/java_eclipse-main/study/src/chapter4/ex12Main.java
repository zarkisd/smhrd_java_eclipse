package chapter4;

import java.util.Scanner;

public class ex12Main {
	public static void main(String[] args) {
		ex12seatreservation SeatReservation = new ex12seatreservation();

		for (int i = 0; i < SeatReservation.SeatType.length; i++) {
			for (int j = 0; j < SeatReservation.SeatType[i].length; j++) {
				SeatReservation.SeatType[i][j] = "--- ";
			}

		}
		Scanner sc = new Scanner(System.in);
		boolean book = true;
		System.out.println("��ǰ�ܼ�ƮȦ ���� �ý����Դϴ�.");

		while (book) {

			System.out.print("����:1, ��ȸ:2, ���:3, ������:4 >>");
			int menu = sc.nextInt();
			switch (menu) {
			case 1:
				SeatReservation.reserve();
				break;
			case 2:
				SeatReservation.show();
				break;
			case 3:
				SeatReservation.cancel();
				break;
			case 4:
				SeatReservation.finish();
				sc.close();
				book = false;
				break;
			default:
				System.out.println("�߸� �Է��Ͽ����ϴ�.");
			}

		}
	}
}
