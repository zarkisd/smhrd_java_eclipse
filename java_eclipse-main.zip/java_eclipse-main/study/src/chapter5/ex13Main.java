package chapter5;

//13 14 ����
public class ex13Main {
	public static void main(String[] args) {
		ex13Shape[] list = new ex13Shape[3];
		list[0] = new ex13Circle(10);//��ĳ����
		list[1] = new ex13Oval(20, 30);
		list[2] = new ex13Rect(10, 40);

		for (int i = 0; i < list.length; i++) {
			list[i].redraw();
		}
		for (int i = 0; i < list.length; i++) {
			System.out.println("������ " + list[i].getArea());
		}

	}
}
