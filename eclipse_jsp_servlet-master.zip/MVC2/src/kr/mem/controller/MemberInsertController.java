package kr.mem.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.mem.model.MemberDAO;
import kr.mem.model.MemberVO;

public class MemberInsertController implements Controller {

	@Override
	public String requestHandler(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String tel = request.getParameter("tel");
		String email = request.getParameter("email");
		String addr = request.getParameter("addr");
		
		MemberDAO dao = new MemberDAO();
		MemberVO vo = new MemberVO(id, pw, name, tel, email, addr);
		
		int cnt = dao.memberInsert(vo);
		if (cnt > 0) {
			return "/MemberList.do";
		} else {
			throw new ServletException("db �Է� ����");
		}
	}

}
