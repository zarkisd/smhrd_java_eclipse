package myPageController;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import kr.drug.model.PillDAO;
import kr.drug.model.PillVO;

@WebServlet("/ajaxMypage_new.do")
public class ajaxMypage_new extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		String pillname=request.getParameter("pillname");
		ArrayList<PillVO> results=list(pillname);
		

		PrintWriter out = response.getWriter();

		Gson gson = new Gson(); // �ڹ� ��ü�� json���·� ��ȯ ���ش�.
		String jsonArr = gson.toJson(results);
		//System.out.println(jsonArr);

		out.write("{\"result\":["+jsonArr+"]}");
		
		String startdate = request.getParameter("startday");
		String starttime=request.getParameter("starttime");
		
		
	
		
		//System.out.println("satrtdate>>"+startdate);
		//System.out.println("starttime>>"+starttime);
		
		
		
	}
public static ArrayList<PillVO> list (String pillname) {
	
	if(pillname==null) {
		pillname="";
	
	
	}
	
	PillDAO dao= new PillDAO();
	System.out.println("����������Դ�."+pillname);
	ArrayList<PillVO> list =dao.getpillList(pillname);
	System.out.println("����� db����. ");
	

	return list;
	
}
}
