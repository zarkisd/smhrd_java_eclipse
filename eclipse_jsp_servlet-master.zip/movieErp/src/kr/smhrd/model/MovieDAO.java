package kr.smhrd.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MovieDAO {

	private Connection conn = null;
	private PreparedStatement psmt = null;
	private ResultSet rs = null;

	private void getConnect() {

		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "hr";
		String password = "hr";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, password);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

	private void getClose() {
		try {
			if (rs != null)
				rs.close();
			if (psmt != null)
				psmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int movieInsert(MovieVO vo) {
		getConnect();
		int result = -1;
		String sql = "insert into tblMovie values(mnum_seq.nextval,?,?,?,?,?)";
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, vo.getMtitle());
			psmt.setString(2, vo.getMname());
			psmt.setInt(3, vo.getMprice());
			psmt.setString(4, vo.getMroom());
			psmt.setString(5, vo.getMloc());
			result = psmt.executeUpdate();
			getClose();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;

	}

	public ArrayList<MovieVO> movieAllList() {

		ArrayList<MovieVO> list = new ArrayList<MovieVO>();

		try {
			getConnect();
			String sql = "select * from tblMovie";
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();

			while (rs.next()) {
				int mnum = rs.getInt(1);
				String mtitle = rs.getString(2); // ������ ù��° Į�� �������ڴ�.
				String mname = rs.getString(3);
				int mprice = rs.getInt(4);
				String mroom = rs.getString(5);
				String mloc = rs.getString(6);

				MovieVO vo = new MovieVO(mnum, mtitle, mname, mprice, mroom, mloc); // ������ �ϳ��� ����!
				list.add(vo);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			getClose();
		}
		return list;
	}

	public int movieDelete(int mnum) {
		getConnect();
		int result = -1;
		String sql = "delete from tblMovie where mnum=?";
		try {

			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, mnum);
			result = psmt.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		getClose();
		return result;

	}

	public MovieVO movieContent(int mnum) {
		MovieVO vo = new MovieVO();
		getConnect();
		String sql = "select * from tblMovie where mnum=?";

		try {
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, mnum);

			rs = psmt.executeQuery();
			while (rs.next()) {
				mnum = rs.getInt(1);
				String mtitle = rs.getString(2); // ������ ù��° Į�� �������ڴ�.
				String mname = rs.getString(3);
				int mprice = rs.getInt(4);
				String mroom = rs.getString(5);
				String mloc = rs.getString(6);

				vo = new MovieVO(mnum, mtitle, mname, mprice, mroom, mloc); // ������ �ϳ��� ����!

			}
			getClose();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return vo;

	}

	public int movieUpdate(MovieVO vo) {
		getConnect();
		int result = -1;
		String sql = "update tblMovie set mprice=?, mroom=?, mloc=? where mnum=?";
		try {
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, vo.getMprice());
			psmt.setString(2, vo.getMroom());
			psmt.setString(3, vo.getMloc());
			psmt.setInt(4, vo.getMnum());
			result = psmt.executeUpdate();
			getClose();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;

	}

}
