package chapter6;

public class ex10Person {
	private String name;
	private int a, b, c;

	public ex10Person(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void random() {
		a = (int) (Math.random() * 3 + 1);
		b = (int) (Math.random() * 3 + 1);
		c = (int) (Math.random() * 3 + 1);
		System.out.println(a + "\t" + b + "\t" + c + "\t");
	}

	public boolean confirm() {
		boolean result = true;
		if (a == b && b == c && c == a) {
			return result;
		} else {
			result = false;
			return result;
		}

	}
}
