package kr.drug.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class BbsDAO {

	private Connection conn;
	private ResultSet rs;

	public BbsDAO() {
		try {
			String dbURL = "jdbc:oracle:thin:@172.30.1.3:1521:XE";
			String dbID = "hr";
			String dbPassword = "hr";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getDatefunc() {
		String SQL = "SELECT TO_CHAR(SYSDATE, 'yyyy-mm-dd hh:mm:ss') FROM DUAL";
		String strdate = "";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				strdate = rs.getString(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return strdate;
	}

	public int getNext() {
		String SQL = "SELECT bbsnum FROM bbs ORDER BY bbsnum desc";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getInt(1) + 1;
			}
			return 1;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	public int write(String bbstitle, int membernum, String bbscontent) {
		String SQL = "INSERT INTO bbs VALUES (?, ?, ?, ?, ?, ?)";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);

			String strdate = getDatefunc();
			pstmt.setInt(1, getNext());
			pstmt.setInt(2, membernum);
			pstmt.setString(3, bbstitle);

			pstmt.setString(4, bbscontent);
			pstmt.setString(5, strdate);
			pstmt.setInt(6, 1);
			return pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	public ArrayList<BbsVO> getList(int pageNumber) {

		String SQL = "select * from (select * from bbs order by bbsnum desc) where bbsnum<? and rownum<=10 and bbsAvailable = 1";

		ArrayList<BbsVO> list = new ArrayList<BbsVO>();

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				BbsVO bbs = new BbsVO();
				bbs.setBbsnum(rs.getInt(1));
				bbs.setMembernum(rs.getInt(2));
				bbs.setBbstitle(rs.getString(3));
				bbs.setBbscontent(rs.getString(4));
				bbs.setBbsdate(rs.getString(5));
				bbs.setBbsAvailable(rs.getInt(6));
				list.add(bbs);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public boolean nextPage(int pageNumber) {
		String SQL = "SELECT * FROM bbs WHERE bbsnum < ? AND bbsAvailable = 1";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false; // �����ͺ��̽� ����
	}

	public BbsVO getBbs(int bbsnum) {
		String SQL = "SELECT * FROM bbs WHERE bbsnum = ?";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, bbsnum);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				BbsVO bbs = new BbsVO();
				bbs.setBbsnum(rs.getInt(1));
				bbs.setMembernum(rs.getInt(2));
				bbs.setBbstitle(rs.getString(3));
				bbs.setBbscontent(rs.getString(4));
				bbs.setBbsdate(rs.getString(5));
				bbs.setBbsAvailable(rs.getInt(6));
				return bbs;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public int update(int bbsnum, String bbstitle, String bbscontent) {
		String SQL = "UPDATE bbs SET bbstitle = ?, bbscontent = ? WHERE bbsnum = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);

			pstmt.setString(1, bbstitle);
			pstmt.setString(2, bbscontent);
			pstmt.setInt(3, bbsnum);
			return pstmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	public int delete(int bbsnum) {
		String SQL = "UPDATE bbs SET bbsAvailable = 0 WHERE bbsnum = ?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, bbsnum);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}

	public MemberVO getMember(int bbsnum) {
		String SQL = "SELECT * FROM member WHERE membernum = (select membernum from bbs where bbsnum=?)";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setInt(1, bbsnum);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				MemberVO vo = new MemberVO();
				vo.setMembernum(rs.getInt(1));
				vo.setId(rs.getString(2));
				vo.setPw(rs.getString(3));
				vo.setName(rs.getString(4));
				vo.setGender(rs.getString(5));
				vo.setEmail(rs.getString(6));
				return vo;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
