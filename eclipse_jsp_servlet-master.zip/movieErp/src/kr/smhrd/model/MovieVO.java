package kr.smhrd.model;

public class MovieVO {

	private int mnum;
	private String mtitle, mname;
	private int mprice;
	private String mroom, mloc;

	public MovieVO(int mnum, String mtitle, String mname, int mprice, String mroom, String mloc) {
		super();
		this.mnum = mnum;
		this.mtitle = mtitle;
		this.mname = mname;
		this.mprice = mprice;
		this.mroom = mroom;
		this.mloc = mloc;
	}

	public MovieVO(String mtitle, String mname, int mprice, String mroom, String mloc) {
		super();
		this.mtitle = mtitle;
		this.mname = mname;
		this.mprice = mprice;
		this.mroom = mroom;
		this.mloc = mloc;
	}

	public MovieVO(int mnum, int mprice, String mroom, String mloc) {
		super();
		this.mnum = mnum;
		this.mprice = mprice;
		this.mroom = mroom;
		this.mloc = mloc;
	}

	public MovieVO() {
		super();
	}

	public int getMnum() {
		return mnum;
	}

	public void setMnum(int mnum) {
		this.mnum = mnum;
	}

	public int getMprice() {
		return mprice;
	}

	public void setMprice(int mprice) {
		this.mprice = mprice;
	}

	public String getMtitle() {
		return mtitle;
	}

	public void setMtitle(String mtitle) {
		this.mtitle = mtitle;
	}

	public String getMname() {
		return mname;
	}

	public void setMname(String mname) {
		this.mname = mname;
	}

	public String getMroom() {
		return mroom;
	}

	public void setMroom(String mroom) {
		this.mroom = mroom;
	}

	public String getMloc() {
		return mloc;
	}

	public void setMloc(String mloc) {
		this.mloc = mloc;
	}

}
