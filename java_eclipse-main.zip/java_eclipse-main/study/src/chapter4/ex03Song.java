package chapter4;

public class ex03Song {
	private String title;
	private String artist;
	private int year;
	private String country;

	public ex03Song(String title, String artist, int year, String country) {
		this.title = title;
		this.artist = artist;
		this.year = year;
		this.country = country;
	}

	public ex03Song() {
	}

	public void show() {
		System.out.printf("%d�� %s������ %s�� �θ� %s", year, country, artist, title);
	}
}
