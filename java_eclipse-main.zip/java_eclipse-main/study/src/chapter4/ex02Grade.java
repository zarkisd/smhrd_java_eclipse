package chapter4;

public class ex02Grade {
	private int math;
	private int science;
	private int english;
	private int score;

	public ex02Grade(int math, int science, int english) {

		this.math = math;
		this.science = science;
		this.english = english;
	}

	public int sum() {
		score = math + science + english;
		return score;
	}

	public double avg() {
		return (double) score / 3;
	}
}
