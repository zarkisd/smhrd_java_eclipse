package km.smhrd.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.smhrd.model.MovieDAO;
import kr.smhrd.model.MovieVO;

/**
 * Servlet implementation class movieUpdate
 */
@WebServlet("/movieUpdate.do")
public class movieUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public movieUpdate() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.setContentType("text/html;charset=EUC-KR");
		request.setCharacterEncoding("EUC-KR");
		MovieDAO dao = new MovieDAO();
		int mnum = Integer.parseInt(request.getParameter("mnum"));
		int mprice = Integer.parseInt(request.getParameter("mprice"));
		String mroom = request.getParameter("mroom");
		String mloc = request.getParameter("mloc");
		MovieVO vo = new MovieVO(mnum, mprice, mroom, mloc);
		if (dao.movieUpdate(vo) > 0) {
			response.sendRedirect("/movieErp/movieList.do");
		} else {
			throw new ServletException("����");
		}

	}

}
