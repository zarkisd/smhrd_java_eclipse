package chapter7;

public class ex10Circle extends ex10Shape {
	String name = "Circle";

	@Override
	public void draw() {
		System.out.println("Circle");
	}
}
