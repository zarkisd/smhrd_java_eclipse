package chapter5;

public class ex01IPTV extends ex01ColorTV {
	protected String ip;

	public ex01IPTV(String ip, int size, int color) {
		super(size, color);
		this.ip = ip;
	}

	@Override
	public void printProperty() {
		System.out.printf("���� IPTV�� %s �ּ��� %d��ġ %d�÷�", ip, getSize(), color);
	}

	public static void main(String[] args) {
		ex01IPTV iptv = new ex01IPTV("192.1.1.2", 32, 2048);
		iptv.printProperty();
	}
}
