package chapter13;

public class TimerRunnable {
	public static void main(String[] args) {
		Thread th = new Thread(new timerRun());
		th.start();
	}
}

class timerRun implements Runnable {
	int n = 0;

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (true) {
			System.out.println(n);
			n++;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				return;
			}
		}
	}

}