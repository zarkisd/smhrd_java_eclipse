package chapter5;

import java.util.Scanner;

public class ex11Main {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("�� ������ �����ڸ� �Է��ϼ���");
		int a = scan.nextInt();
		int b = scan.nextInt();
		String c = scan.next();
		ex11Add A = new ex11Add();
		ex11Sub B = new ex11Sub();
		ex11Mul C = new ex11Mul();
		ex11Div D = new ex11Div();
		switch (c) {
		case "+":
			A.setValue(a, b);
			System.out.println(A.calculate());
			break;
		case "-":
			B.setValue(a, b);
			System.out.println(B.calculate());
			break;
		case "*":
			C.setValue(a, b);
			System.out.println(C.calculate());
			break;
		case "/":
			D.setValue(a, b);
			System.out.println(D.calculate());
			break;
		}

	}
}
