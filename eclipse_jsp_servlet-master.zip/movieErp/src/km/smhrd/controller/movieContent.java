package km.smhrd.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.smhrd.model.MovieDAO;
import kr.smhrd.model.MovieVO;



/**
 * Servlet implementation class movieContent
 */
@WebServlet("/movieContent.do")
public class movieContent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		MovieDAO dao = new MovieDAO();
		int mnum = Integer.parseInt(request.getParameter("mnum"));
		MovieVO vo = dao.movieContent(mnum);
		
		request.setAttribute("vo", vo);//��ü���ε�
		RequestDispatcher rd = request.getRequestDispatcher("movie/movieContent.jsp");
		rd.forward(request, response);
	}

}
