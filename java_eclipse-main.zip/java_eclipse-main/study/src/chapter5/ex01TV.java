package chapter5;

class ex01TV {

	private int size;

	public ex01TV(int size) {
		this.size = size;
	}

	protected int getSize() {
		return size;
	}

}
