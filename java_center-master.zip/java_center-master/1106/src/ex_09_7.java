
public class ex_09_7 {

	public static void main(String[] args) {

	

		System.out.println("2��");
		for (int i = 1; i <= 9; i++) {
			System.out.printf("2*%d=%d\n", i, 2 * i);
		}

		System.out.println("3��");
		for (int i = 1; i <= 9; i++) {
			System.out.printf("3*%d=%d\n", i, 3 * i);
		}

		
		
		System.out.println("4��");
		for (int i = 1; i <= 9; i++) {
			System.out.printf("4*%d=%d\n", i, 4 * i);
		}
	}

}
