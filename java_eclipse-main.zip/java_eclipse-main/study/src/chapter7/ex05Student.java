package chapter7;


public class ex05Student {
	private String name, department;
	// �̸�, �а�
	private int number;
	private double grade;
	// �й�, ���� ���

	public ex05Student(String name, String department, int number, double grade) {
		this.name = name;
		this.department = department;
		this.number = number;
		this.grade = grade;
	}

	public ex05Student() {
	}

	public String getName() {
		return name;
	}

	public String getDepartment() {
		return department;
	}

	public int getNumber() {
		return number;
	}

	public double getGrade() {
		return grade;
	}

}
